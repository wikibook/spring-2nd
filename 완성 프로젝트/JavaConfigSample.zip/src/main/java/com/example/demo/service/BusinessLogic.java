package com.example.demo.service;

public interface BusinessLogic {
	/** 처리 */
	void doLigic();
}
