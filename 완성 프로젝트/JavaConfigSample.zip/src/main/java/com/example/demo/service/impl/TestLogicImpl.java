package com.example.demo.service.impl;

import com.example.demo.service.BusinessLogic;

public class TestLogicImpl implements BusinessLogic {
	@Override
	public void doLigic() {
		System.out.println("테스트 중입니다.");
	}
}