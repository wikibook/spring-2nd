package com.example.demo.service.impl;

import com.example.demo.service.BusinessLogic;

public class SampleLogicImpl implements BusinessLogic {
	@Override
	public void doLigic() {
		System.out.println("샘플입니다.");
	}
}