package com.example.demo.used;

/**
 * 아침 인사 하기
*/
//@Component
public class MorningGreet implements Greet {
	@Override
	public String greeting() {
		return "좋은 아침입니다.";
	}
}
