package com.example.demo.used;

/**
* 인사말 인터페이스
*/
public interface Greet {
	/**
	 * 인사말 하기
	 * @return 인사말
	*/
	String greeting();
}