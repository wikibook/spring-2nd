package com.example.demo.entity;

import lombok.Data;

@Data
public class Publisher {
	/** 출판사 ID */
	private int id;
	/** 출판사명 */
	private String name;
}