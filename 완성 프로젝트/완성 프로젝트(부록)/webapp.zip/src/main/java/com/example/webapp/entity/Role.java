package com.example.webapp.entity;

public enum Role {
	ADMIN, USER
}