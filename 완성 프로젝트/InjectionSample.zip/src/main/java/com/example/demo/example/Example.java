package com.example.demo.example;

public interface Example {
	/** 실행 */
	void run();
}