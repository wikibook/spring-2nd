package com.example.demo.service;

import org.springframework.stereotype.Component;

@Component
public class SomeService {

	/** 서비스 처리 */
	public void doService() {
		System.out.println("어떤 서비스");
	}
}